<?php

namespace App\Http\Controllers;
use App\Participante;
use App\User;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class TCP_Client {

            function __construct($ip, $port, $mensaje) {

                
                $sk =  @fsockopen($ip, $port,$errnum,$errstr,30);

                if (!is_resource($sk)) {
                     exit("connection fail: ".$errnum." ".$errstr) ;
                 } else {
 
                 echo "Connected";
                 $data_packet = $this->CreateDataPacket($mensaje);
                 foreach ($data_packet as $ele) {
                     $ret = fwrite($sk, $ele);
                     echo $ele;
                 }
                 }
            }

            function CustomMerge(&$target_array, $target_data) {
                foreach ($target_data as $key => $value) {
                    $target_array[count($target_array)] = chr($value);
                }
            }

            function CreateDataPacket($data) {
                $packet = array();
                $packet[count($packet)] = chr(2); //initialize
                $this->CustomMerge($packet, unpack('C*', strlen($data)));
                $packet[count($packet)] = chr(4); //separator
                $this->CustomMerge($packet, unpack('C*', $data));
                return $packet;
            }

        }
        
class webhookController extends Controller
{
    
   
    public function acreditar(Request $request){
        
        if ($request->isMethod('post')){
            $id = $request->all();
            $id = str_replace("https://www.eventbriteapi.com/v3/events/6630649451/attendees/", "", $id['api_url']);
            $id = str_replace("/", "", $id);
            //echo $id;
            //print_r($id['config']['user_id']);
        }
        
        //Participante::create(['nombre'=>'facundo','eventbrite_id'=>$id]);
        
        if(Participante::where('eventbrite_id', $id)->exists()){
                
            Participante::where('eventbrite_id', $id)
                          ->update(['estadoParticipante' => 1]);
        
        
        //LLAMAMOS A LA FUNCION PARA IMPRIMIR
        
        $this->imprimirCredencial($id);
    
        }else{
            echo 'No se acredito';
        }
        
   }
   
   
   
    /*   public function desacreditar(Request $request){
        
        if ($request->isMethod('post')){
            $id = $request->all();
            $id = str_replace("https://www.eventbriteapi.com/v3/events/6630649451/attendees/", "", $id['api_url']);
            $id = str_replace("/", "", $id);
            //echo $id;
            //print_r($id['config']['user_id']);
        }
        
        
        if(Participante::where('eventbrite_id', $id)->exists()){
                
            Participante::where('eventbrite_id', $id)
                          ->update(['estadoParticipante' => 0]);
    
        }else{
            echo 'No se desacredito';
        }
        
   }
   
   */

   
   
   public function imprimirCredencial($idEventbrite)
   {
        $data = Participante::where('eventbrite_id', $idEventbrite)
                            ->get();
        $data = $data->toArray();
        $data = array_first($data);
        
        $nombre = $data['nombre'];
        $apellido = $data ['apellido'];
        $empresa = $data ['company'];
        $empleo = $data['empleo'];
        $celular = $data['celular'];
        $email = $data['email'];
        $ticketType = $data['ticket_type'];
        $dni = $data['dni'];
        $departamento = $data['workCity'];
        $provincia = $data['workState'];
        $ip = '52.15.62.13';
        $port = 17834;
        
        $zpl = '^XA'.
                  '^CFA,42'.
                  '^FO150,35^FD'.$ticketType.'^FS'.
                  '^CFA,32'.
                  '^FO50,110^FD'.$nombre.' '.$apellido.'^FS'.
                  '^CFA,23'. 
                  '^FO50,170^FD'.$empresa.'-'.$empleo.'^FS'.
                  '^FO250,250^FD'.$departamento.','.'^FS'.
                  '^FO250,275^FD'.$provincia.'^FS'.
                  '^FO50,132^BY2,2,95^BQ,2,3'.
                  '^FH_^FDHM,A'.$nombre.' '.$apellido.'/'.$empresa.'-'.$empleo.'/'.$celular.'/'.$email.'/'.$dni.'^FS'.
                  '^XZ';

           $obj_client = new TCP_Client($ip,$port,$zpl); 
   }
   
   public function imprimirCredencialVista($idEventbrite)
   {
        $data = Participante::where('eventbrite_id', $idEventbrite)
                            ->get();
        $data = $data->toArray();
        $data = array_first($data);
        
        $nombre = $data['nombre'];
        $apellido = $data ['apellido'];
        $empresa = $data ['company'];
        $empleo = $data['empleo'];
        $celular = $data['celular'];
        $email = $data['email'];
        $ticketType = $data['ticket_type'];
        $dni = $data['dni'];
        $departamento = $data['workCity'];
        $provincia = $data['workState'];
        $ip = '52.15.62.13';
        $port = 17834;
        
        $zpl = '^XA'.
                  '^CFA,42'.
                  '^FO150,35^FD'.$ticketType.'^FS'.
                  '^CFA,32'.
                  '^FO50,110^FD'.$nombre.' '.$apellido.'^FS'.
                  '^CFA,23'. 
                  '^FO50,170^FD'.$empresa.'-'.$empleo.'^FS'.
                  '^FO250,250^FD'.$departamento.','.'^FS'.
                  '^FO250,275^FD'.$provincia.'^FS'.
                  '^FO50,132^BY2,2,95^BQ,2,3'.
                  '^FH_^FDHM,A'.$nombre.' '.$apellido.'/'.$empresa.'-'.$empleo.'/'.$celular.'/'.$email.'/'.$dni.'^FS'.
                  '^XZ';

           $obj_client = new TCP_Client($ip,$port,$zpl); 
        
        return redirect()->back()->with('mensaje', 'Credencial impresa correctamente');

   }
   
   /**
      public function inscribir(Request $request){
       if ($request->isMethod('post')){
            $id = $request->all();
            $id = str_replace("https://www.eventbriteapi.com/v3/events/6630649451/attendees/", "", $id['api_url']);
            $id = str_replace("/", "", $id);
       }
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, "https://www.eventbriteapi.com/v3/events/6630649451/attendees/$id/");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          "Authorization: Bearer LIXXAORLSQTQ5VTYDEIO",
          "Content-Type: application/json"
        ));
        
        $response = curl_exec($ch);
        curl_close($ch);
        $response= json_decode($response);
        
        $idEventbrite = $response->id;
        $nombre = $response->profile->first_name;
        $apellido = $response->profile->last_name;
        $email = $response->profile->email;
        $ticket_type= $response->ticket_class_name;
        $celular= $response->profile->cell_phone;
        $dni = $response->answers[0]->answer;
        $ponencia = $response->answers[1]->answer;
        $entidadP = $response->answers[2]->answer;
        $solEspFeria = $response->answers[3]->answer;
        $solTrasTerr = $response->answers[4]->answer;
        $areaInteres = $response->answers[5]->answer;
        $empleo= $response->profile->job_title;
        $company= $response->profile->company;
        $workAddress1= $response->profile->addresses->work->address_1;
      if(isset($response->profile->addresses->work->address_2)){  $workAddress2=$response->profile->addresses->work->address_2; } else {$workAddress2 = "";}
        $city= $response->profile->addresses->work->city;
      if(isset( $response->profile->addresses->work->region)){ $region= $response->profile->addresses->work->region; } else {$region = "";}
        $postalCode= $response->profile->addresses->work->postal_code;
        $country= $response->profile->addresses->work->country;
    
    if(Participante::where('eventbrite_id', $idEventbrite)->exists())
    {echo 'ya existe';}
    else{
      Participante::create(['eventbrite_id'=>$idEventbrite,
                             'nombre'=>$nombre,
                             'apellido'=>$apellido,
                             'email'=>$email,
                             'ticket_type'=>$ticket_type,
                             'celular'=>$celular,
                             'dni'=>$dni,
                             'ponencia'=>$ponencia,
                             'entidadP'=>$entidadP,
                             'solicitudEspacioFeria'=>$solEspFeria,
                             'solicitudTrasladoTerrestre'=>$solTrasTerr,
                             'areaDeInteres'=>$areaInteres,
                             'empleo'=>$empleo,
                             'company'=>$company,
                             'workAdress1'=>$workAddress1,
                             'workAdress2'=>$workAddress2,
                             'workCity'=>$city,
                             'workState'=>$region,
                             'workCountry'=>$country]);   
    }
   
    
       

        
   } */
   
   
   
   
   
   
}

