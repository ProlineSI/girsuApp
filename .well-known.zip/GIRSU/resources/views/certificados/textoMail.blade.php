Hola!
Nos comunicamos con usted para enviarle adjunto el certificado que consta su participacion en el II Congreso Internacional sobre Gestion Integral de residuos solidos urbanos.
Saludos Coordiales. 
Gracias.

Atte Sergio Espinoza Rodriguez - Director General de Residuos Solidos Urbanos. 